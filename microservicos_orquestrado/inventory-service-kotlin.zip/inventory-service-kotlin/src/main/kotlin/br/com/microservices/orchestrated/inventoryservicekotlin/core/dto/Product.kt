package br.com.microservices.orchestrated.inventoryservicekotlin.core.dto;


data class Product(
    val code: String,
    val unitValue: Double
)
