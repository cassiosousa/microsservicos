package br.com.microservices.orchestrated.inventoryservicekotlin.core.rules

import br.com.microservices.orchestrated.inventoryservicekotlin.core.dto.Event

interface InventoryRules {
    fun perform( event:Event)
}