package br.com.microservices.orchestrated.inventoryservicekotlin.core.rules

import br.com.microservices.orchestrated.inventoryservice.config.exception.ValidationException
import br.com.microservices.orchestrated.inventoryservicekotlin.core.dto.Event
import br.com.microservices.orchestrated.inventoryservicekotlin.core.dto.OrderProducts
import br.com.microservices.orchestrated.inventoryservicekotlin.core.model.Inventory
import br.com.microservices.orchestrated.inventoryservicekotlin.core.repository.InventoryRepository

class CheckInventoryRule(
    private val inventoryRepository: InventoryRepository
) : ProductRules {


    override fun perform(event: Event, product: OrderProducts) {
        val inventory = findByInventoryProductCode(product.product.code)
        checkInventory(inventory.available, product.quantity)
    }

    private fun findByInventoryProductCode(productCode: String): Inventory =
        inventoryRepository.findByProductCode(productCode)?.let { inventory -> inventory }
            ?: throw ValidationException("Inventory not found by informed product.")

    private fun checkInventory(available: Int, orderQuantity: Int) {
        if (orderQuantity > available) {
            throw ValidationException(("Product is out of stock!"));
        }
    }
}