package br.com.microservices.orchestrated.inventoryservicekotlin.core.rules

import br.com.microservices.orchestrated.inventoryservicekotlin.core.dto.Event
import br.com.microservices.orchestrated.inventoryservicekotlin.core.dto.OrderProducts
import br.com.microservices.orchestrated.inventoryservicekotlin.core.dto.Product

interface ProductRules {
    fun perform(event:Event, product: OrderProducts)
}