insert into public.inventory(id,product_code, available) values(1,'COMIC_BOOKS', 4);
insert into public.inventory(id,product_code, available) values(2,'BOOKS', 2);
insert into public.inventory(id,product_code, available) values(3,'MOVIES', 5);
insert into public.inventory(id,product_code, available) values(4,'MUSIC', 9);