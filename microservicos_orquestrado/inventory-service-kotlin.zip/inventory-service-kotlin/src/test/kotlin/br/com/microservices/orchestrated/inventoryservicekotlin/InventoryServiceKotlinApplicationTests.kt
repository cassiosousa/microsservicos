package br.com.microservices.orchestrated.inventoryservicekotlin

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class InventoryServiceKotlinApplicationTests: AbstractIntegrationTest() {

	@Test
	fun contextLoads() {
	}

}
