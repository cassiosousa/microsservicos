package br.com.microservices.orchestrated.inventoryservicekotlin

import org.junit.jupiter.api.extension.ExtendWith
import org.springframework.boot.autoconfigure.ImportAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureWebMvc
import org.springframework.boot.test.context.SpringBootTest


//@Target(AnnotationTarget.TYPE, AnnotationTarget.CLASS)
//@Retention(AnnotationRetention.RUNTIME)
//@SpringBootTest(classes = [TestInventoryServiceKotlinApplication::class])
//@AutoConfigureWebMvc
//@AutoConfigureMockMvc
//@ImportAutoConfiguration
//annotation class  IntegrationTest {
//}