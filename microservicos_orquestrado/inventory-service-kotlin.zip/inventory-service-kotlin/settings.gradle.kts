rootProject.name = "inventory-service-kotlin"
